/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class AjusteInventario {
    private int id_Ajuste;
    private int id_Producto;
    private int cantidad_ajustada;
    private char Motivo;
    private int Fecha;
    private int id_Usuario;

    public AjusteInventario(int id_Ajuste, int id_Producto, int cantidad_ajustada, char Motivo, int Fecha, int id_Usuario) {
        this.id_Ajuste = id_Ajuste;
        this.id_Producto = id_Producto;
        this.cantidad_ajustada = cantidad_ajustada;
        this.Motivo = Motivo;
        this.Fecha = Fecha;
        this.id_Usuario = id_Usuario;
    }

    public int getId_Ajuste() {
        return id_Ajuste;
    }

    public void setId_Ajuste(int id_Ajuste) {
        this.id_Ajuste = id_Ajuste;
    }

    public int getId_Producto() {
        return id_Producto;
    }

    public void setId_Producto(int id_Producto) {
        this.id_Producto = id_Producto;
    }

    public int getCantidad_ajustada() {
        return cantidad_ajustada;
    }

    public void setCantidad_ajustada(int cantidad_ajustada) {
        this.cantidad_ajustada = cantidad_ajustada;
    }

    public char getMotivo() {
        return Motivo;
    }

    public void setMotivo(char Motivo) {
        this.Motivo = Motivo;
    }

    public int getFecha() {
        return Fecha;
    }

    public void setFecha(int Fecha) {
        this.Fecha = Fecha;
    }

    public int getId_Usuario() {
        return id_Usuario;
    }

    public void setId_Usuario(int id_Usuario) {
        this.id_Usuario = id_Usuario;
    }

    @Override
    public String toString() {
        return "AjusteInventario{" + "id_Ajuste=" + id_Ajuste + ", id_Producto=" + id_Producto + ", cantidad_ajustada=" + cantidad_ajustada + ", Motivo=" + Motivo + ", Fecha=" + Fecha + ", id_Usuario=" + id_Usuario + '}';
    }
    
    
}
