/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class Proveedor {
    private int id_Proveedor;
    private char Nombre_Empresa;
    private char Nombre_Contacto;
    private int Telefono;
    private char Correo;
    private char Direccion;
    private char Ciudad;
    private char Pais;
    private char Estado;

    public Proveedor(int id_Proveedor, char Nombre_Empresa, char Nombre_Contacto, int Telefono, char Correo, char Direccion, char Ciudad, char Pais, char Estado) {
        this.id_Proveedor = id_Proveedor;
        this.Nombre_Empresa = Nombre_Empresa;
        this.Nombre_Contacto = Nombre_Contacto;
        this.Telefono = Telefono;
        this.Correo = Correo;
        this.Direccion = Direccion;
        this.Ciudad = Ciudad;
        this.Pais = Pais;
        this.Estado = Estado;
    }

    public int getId_Proveedor() {
        return id_Proveedor;
    }

    public void setId_Proveedor(int id_Proveedor) {
        this.id_Proveedor = id_Proveedor;
    }

    public char getNombre_Empresa() {
        return Nombre_Empresa;
    }

    public void setNombre_Empresa(char Nombre_Empresa) {
        this.Nombre_Empresa = Nombre_Empresa;
    }

    public char getNombre_Contacto() {
        return Nombre_Contacto;
    }

    public void setNombre_Contacto(char Nombre_Contacto) {
        this.Nombre_Contacto = Nombre_Contacto;
    }

    public int getTelefono() {
        return Telefono;
    }

    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }

    public char getCorreo() {
        return Correo;
    }

    public void setCorreo(char Correo) {
        this.Correo = Correo;
    }

    public char getDireccion() {
        return Direccion;
    }

    public void setDireccion(char Direccion) {
        this.Direccion = Direccion;
    }

    public char getCiudad() {
        return Ciudad;
    }

    public void setCiudad(char Ciudad) {
        this.Ciudad = Ciudad;
    }

    public char getPais() {
        return Pais;
    }

    public void setPais(char Pais) {
        this.Pais = Pais;
    }

    public char getEstado() {
        return Estado;
    }

    public void setEstado(char Estado) {
        this.Estado = Estado;
    }

    @Override
    public String toString() {
        return "Proveedor{" + "id_Proveedor=" + id_Proveedor + ", Nombre_Empresa=" + Nombre_Empresa + ", Nombre_Contacto=" + Nombre_Contacto + ", Telefono=" + Telefono + ", Correo=" + Correo + ", Direccion=" + Direccion + ", Ciudad=" + Ciudad + ", Pais=" + Pais + ", Estado=" + Estado + '}';
    }
    
    
}
