/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class Ubicacion {
    private int id_Ubicacion;
    private char Nombre;
    private char Descripcion;

    public Ubicacion(int id_Ubicacion, char Nombre, char Descripcion) {
        this.id_Ubicacion = id_Ubicacion;
        this.Nombre = Nombre;
        this.Descripcion = Descripcion;
    }

    public int getId_Ubicacion() {
        return id_Ubicacion;
    }

    public void setId_Ubicacion(int id_Ubicacion) {
        this.id_Ubicacion = id_Ubicacion;
    }

    public char getNombre() {
        return Nombre;
    }

    public void setNombre(char Nombre) {
        this.Nombre = Nombre;
    }

    public char getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(char Descripcion) {
        this.Descripcion = Descripcion;
    }

    @Override
    public String toString() {
        return "Ubicacion{" + "id_Ubicacion=" + id_Ubicacion + ", Nombre=" + Nombre + ", Descripcion=" + Descripcion + '}';
    }
    
    
}
