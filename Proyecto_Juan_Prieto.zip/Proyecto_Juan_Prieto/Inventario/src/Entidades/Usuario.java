/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author alejo
 */
public class Usuario {
    private int id_Usuario;
    private char Nombre;
    private char Usuario;
    private char Contraseña;
    private char Rol;
    private int Fecha_Creacion;
    private char Activo;

    public Usuario(int id_Usuario, char Nombre, char Usuario, char Contraseña, char Rol, int Fecha_Creacion, char Activo) {
        this.id_Usuario = id_Usuario;
        this.Nombre = Nombre;
        this.Usuario = Usuario;
        this.Contraseña = Contraseña;
        this.Rol = Rol;
        this.Fecha_Creacion = Fecha_Creacion;
        this.Activo = Activo;
    }

    public int getId_Usuario() {
        return id_Usuario;
    }

    public void setId_Usuario(int id_Usuario) {
        this.id_Usuario = id_Usuario;
    }

    public char getNombre() {
        return Nombre;
    }

    public void setNombre(char Nombre) {
        this.Nombre = Nombre;
    }

    public char getUsuario() {
        return Usuario;
    }

    public void setUsuario(char Usuario) {
        this.Usuario = Usuario;
    }

    public char getContraseña() {
        return Contraseña;
    }

    public void setContraseña(char Contraseña) {
        this.Contraseña = Contraseña;
    }

    public char getRol() {
        return Rol;
    }

    public void setRol(char Rol) {
        this.Rol = Rol;
    }

    public int getFecha_Creacion() {
        return Fecha_Creacion;
    }

    public void setFecha_Creacion(int Fecha_Creacion) {
        this.Fecha_Creacion = Fecha_Creacion;
    }

    public char getActivo() {
        return Activo;
    }

    public void setActivo(char Activo) {
        this.Activo = Activo;
    }

    @Override
    public String toString() {
        return "Usuario{" + "id_Usuario=" + id_Usuario + ", Nombre=" + Nombre + ", Usuario=" + Usuario + ", Contrase\u00f1a=" + Contraseña + ", Rol=" + Rol + ", Fecha_Creacion=" + Fecha_Creacion + ", Activo=" + Activo + '}';
    }
    
    
}
